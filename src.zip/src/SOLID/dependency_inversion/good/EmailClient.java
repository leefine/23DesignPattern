package SOLID.dependency_inversion.good;

/**
 * Created by mrk on 4/8/14.
 */
public class EmailClient implements Notifier {
    public void alertWeatherConditions(String weatherConditions) {
        if (weatherConditions == "sunny");
            System.out.print("It is sunny");
    }
}
