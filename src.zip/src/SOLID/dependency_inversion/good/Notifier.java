package SOLID.dependency_inversion.good;

/**
 * Created by mrk on 4/8/14.
 */
interface Notifier {
    public void alertWeatherConditions(String weatherConditions);
}
