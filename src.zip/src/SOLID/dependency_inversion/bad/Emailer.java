package SOLID.dependency_inversion.bad;

/**
 * Created by mrk on 4/8/14.
 */
public class Emailer {
    public String generateWeatherAlert(String weatherConditions) {
        String alert = "It is " + weatherConditions;
        return alert;
    }
}
