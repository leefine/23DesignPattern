package SOLID.open_closed.good;

/**
 * Created by mrk on 4/7/14.
 */
public interface Personality {
    public String greet();
}
