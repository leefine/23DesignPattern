package SOLID.open_closed.good;

/**
 * Created by mrk on 4/7/14.
 */
public class FormalPersonality implements Personality {
    public String greet() {
        return "Good evening, sir.";
    }
}
