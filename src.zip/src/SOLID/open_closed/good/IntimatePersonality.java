package SOLID.open_closed.good;

/**
 * Created by mrk on 4/7/14.
 */
public class IntimatePersonality implements Personality {
    public String greet() {
        return "Hello Darling!";
    }
}
