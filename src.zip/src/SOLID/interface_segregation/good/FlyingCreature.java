package SOLID.interface_segregation.good;

/**
 * Created by mrk on 4/7/14.
 */
public interface FlyingCreature {
    public void fly();
}
