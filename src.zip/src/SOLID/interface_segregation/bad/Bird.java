package SOLID.interface_segregation.bad;

/**
 * Created by mrk on 4/7/14.
 */
public interface Bird {

    public void fly();

    public void molt();
}
