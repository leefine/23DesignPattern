package SOLID.liskov_substitution.good;

public class Movie extends Product {
    public Movie(String name, String author) {
        super(name, author);
    }

}