package Pattern.StructPattern.ProxyPattern.example1;

/**
 * Created by zhangjinqiang on 2017-8-19.
 */
public class JavaCoder implements Coder {
    @Override
    public void code() {
        System.out.println("java code");
    }
}
