package Pattern.StructPattern.ProxyPattern.example2;

/**
 * Created by zhangjinqiang on 2017-11-2.
 */
public interface SaleHouse {
    void sale();
}
