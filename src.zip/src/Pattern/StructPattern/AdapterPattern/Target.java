package Pattern.StructPattern.AdapterPattern;

public interface Target {
	String request();	
}