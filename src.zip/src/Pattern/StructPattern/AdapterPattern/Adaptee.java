package Pattern.StructPattern.AdapterPattern;

public class Adaptee {

	public String specialRequest(){
        return "specialRequest";
	}
}