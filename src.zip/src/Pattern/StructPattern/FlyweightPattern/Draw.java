package Pattern.StructPattern.FlyweightPattern;

/**
 * 画笔接口 可以画画
 */
public interface Draw {
    void draw();
}
