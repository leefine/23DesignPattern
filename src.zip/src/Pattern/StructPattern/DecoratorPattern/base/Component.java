package Pattern.StructPattern.DecoratorPattern.base;


public interface Component {

    void operation();

}
