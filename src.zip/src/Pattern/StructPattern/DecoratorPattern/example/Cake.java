package Pattern.StructPattern.DecoratorPattern.example;

public interface Cake {
    void make();
}
