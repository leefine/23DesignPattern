package Pattern.BehavioralPattern.VistorPattern;


public interface FamousPlace {
    void accept(Vistor vistor);
}
