package Pattern.BehavioralPattern.CommandPattern;

/***
 * 命令接口
 */
public interface Command {
    void execute();
}
