package Pattern.CreationalPattern.FactoryPattern.abstract_factory.base;


public abstract class AbstractProductB {
    public abstract void doB();
}
