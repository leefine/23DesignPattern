package Pattern.CreationalPattern.FactoryPattern.abstract_factory.base;


public abstract class AbstractProductA {

    public abstract void doA();

}
