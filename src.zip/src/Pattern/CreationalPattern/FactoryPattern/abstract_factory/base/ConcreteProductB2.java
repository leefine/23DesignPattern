package Pattern.CreationalPattern.FactoryPattern.abstract_factory.base;


public class ConcreteProductB2 extends AbstractProductB {
    @Override
    public void doB() {
        System.out.println("Concrete Product B 2");
    }

}