package Pattern.CreationalPattern.FactoryPattern.abstract_factory.base;


public class ConcreteProductA2 extends AbstractProductA {
    @Override
    public void doA() {
        System.out.println("Concrete Product A 2");
    }

}