package Pattern.CreationalPattern.FactoryPattern.abstract_factory.example;

/**

 * 抽象造型产品
 */
public abstract class CakeStyle {
    public abstract void style();
}
