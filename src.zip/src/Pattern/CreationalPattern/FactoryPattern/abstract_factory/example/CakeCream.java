package Pattern.CreationalPattern.FactoryPattern.abstract_factory.example;

/**

 * 抽象奶油产品
 */
public abstract class CakeCream {
    public abstract void cream();
}
