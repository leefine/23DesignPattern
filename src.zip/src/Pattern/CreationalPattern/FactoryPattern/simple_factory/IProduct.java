package Pattern.CreationalPattern.FactoryPattern.simple_factory;

/**
 * Created by Administrator on 2015/4/22.
 */
public interface IProduct {
    public void getProperty();
}
